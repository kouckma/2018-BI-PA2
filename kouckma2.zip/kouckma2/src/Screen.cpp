
#include"Screen.hpp"

Screen::Screen(void) {
    getmaxyx(stdscr, curry, currx);
}

Screen::~Screen() {
}

void Screen::createWindow(int x, int y, int posx, int posy) {
    win = newwin(y, x, posy, posx);
}
