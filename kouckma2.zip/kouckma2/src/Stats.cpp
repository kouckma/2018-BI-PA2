
#include "Stats.hpp"

Stats::Stats() {
}

void Stats::showStats() {
    box(win, 0, 0);
    wmove(win, 1, 0);
    wprintw(win, "  HEALTH: ");
    for (int i = 0; i < statLives; i++) wprintw(win, "0");
    wprintw(win, "\n");
    wprintw(win, "  SCORE: %d points\n", statScore);
    wprintw(win, "  MONEY: %d $\n\n", statMoney);
    wprintw(win, "  TYPE  | KEY | COST\n");
    wprintw(win, "  =================\n");
    wprintw(win, "  WALL  | -1- | %d\n", WALLCOST);
    wprintw(win, "  STUN  | -2- | %d\n", STUNCOST);
    wprintw(win, "  BASIC | -3- | %d\n", BASICCOST);
    wprintw(win, "  HEAVY | -4- | %d\n", UPGRADEDCOST);
    box(win, 0, 0);
    wrefresh(win);
    refresh();
}

Stats::~Stats() {
}

