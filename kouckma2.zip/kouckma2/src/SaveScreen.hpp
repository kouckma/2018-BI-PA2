
#include "Screen.hpp"

/**
 * This class handles showing user input when typing in the name of the save.
 */
class SaveScreen : public Screen {
public:
    /**
     * Empty constructor.
     */
    SaveScreen(void);
    /**
     * Empty destructor.
     */
    ~SaveScreen(void);
    /**
     * Reads user input and returns full name of the save.
     * @param [out] save name of the save
     */
    string getInput();
};