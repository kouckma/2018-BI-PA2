
#include "WinScreen.hpp"

WinScreen::WinScreen() {
}

void WinScreen::showWinScreen(int inScore) {
    nodelay(stdscr, FALSE);
    mvwprintw(win, (curry / 2) - 3, (currx / 2) - 14, "***************************");
    mvwprintw(win, (curry / 2) - 2, (currx / 2) - 14, "***************************");
    mvwprintw(win, (curry / 2) - 1, (currx / 2) - 14, "      !!! YOU WON !!!        ");
    mvwprintw(win, (curry / 2) - 0, (currx / 2) - 14, "***************************");
    mvwprintw(win, (curry / 2) + 1, (currx / 2) - 14, "***************************");
    mvwprintw(win, (curry / 2) + 3, (currx / 2) - 14, "      your score: %d", inScore);
    mvwprintw(win, (curry / 2) + 5, (currx / 2) - 15, "--press any key to continue--");
    box(win, '*', '*');
    wrefresh(win);
    refresh();
    getch();
}

WinScreen::~WinScreen() {
}


