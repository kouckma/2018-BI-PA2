
#ifndef GAME_H
#define GAME_H


#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <ncurses.h>
#include <vector>
#include <queue>
#include <set>
#include <algorithm>

#include"Screen.hpp"

#include"Elements/Element.hpp"

#include"Elements/Tower.hpp"
#include"Elements/Wall.hpp"
#include"Elements/Enemy.hpp"
#include"Elements/Start.hpp"
#include"Elements/Fin.hpp"
#include"Elements/Ground.hpp"
#include"Elements/Enemies/Boss.hpp"
#include"Elements/Enemies/Mob.hpp"
#include"Elements/Towers/UpgradedTower.hpp"
#include"Elements/Towers/StunTower.hpp"
#include"Elements/Towers/BasicTower.hpp"

#include"Display.hpp"
#include"Stats.hpp"
#include"ControlsScreen.hpp"
#include"LooseScreen.hpp"
#include"WinScreen.hpp"
#include"SaveScreen.hpp"


#include"Constants.hpp"


using namespace std;

/**
 * Main game class, takes care of all features of gameplay and saving.
 */

class Game : public Screen {
protected:
    /**
     * Information about where the game map is located.
     */
    string mapDestination;
    /**
     * Char for reading input from file.
     */
    char c;
    /**
     * Int for reading input from keyboard.
     */
    int input = 0;
    /**
     * Determines whether there is a shown error.
     */
    int errorUP = 0;
    /**
     * Determines whether the spawns are spawning enemies (for cheating purposes).
     */
    int spawnUP = 1;
    /**
     * Determines which building is currently chosen.
     */
    int chosen = 0;
    /**
     * Values of score, lives and money.
     */
    int score = 0, lives = STARTLIVES, money = STARTGOLD;
    /**
     * X and Y values of size of the map.
     */
    int sizex = 0, sizey = 0;
    /**
     * Current X and Y positions of the cursor.
     */
    int cursx = 0, cursy = 0;
    /**
     * Vector of pointers to Elements.
     * Represents game map.
     */
    vector<vector<Element*> > map;
    /**
     * Vector of pointers to Elements.
     * Used as representation of next move/future map.
     */
    vector<vector<Element*> > newmap;
    /**
     * Used during initialization for reading from file.
     */
    vector<char> initmap;
    /**
     * Determines whether new map must be allocated or only set to NULL values.
     */
    int newMapIsSet = 0;
    /**
     * Determines if the game has ended.
     */
    int ended = 0;
    /**
     * Determines if the game has been won.
     */
    int won = 0;
    /**
     * Difficulty of the game.
     */
    int difficulty = 1;
    /**
     * Info about current statistics.
     */
    Stats statWindow;
    /**
     * Info about controls.
     */
    ControlsScreen controlsWindow;
public:

    /**
     * Constructor for game created as New Game.
     * @param [in] srcMap destination of map
     * @param [in] inDifficulty difficulty of the game
     */
    Game(string srcMap, int inDifficulty = 1);

    /**
     * Constructor for game created as Load Game.
     * @param [in] srcMap destination of map
     * @param [in] srcInit destination of initialization file
     * @param [in] inDifficulty difficulty of the game
     */
    Game(string srcMap, string srcInit, int inDifficulty = 1);

    /**
     * Destructor that deletes objects from map and newmap.
     */
    ~Game();
private:

    /**
     * Ensures initialization of the game.
     * Sets up both maps.
     */
    void gameInit();

    /**
     * Initialization of statistics from saved game.
     * @param [in] srcInit destination of required initialization files.
     */
    void statsInit(string srcInit);

    /**
     * Reads from file and initializes 'initmap' 
     * Sets up sizes X and Y.
     */
    void presetMap();

    /**
     * Sets up both maps to NULL values.
     */
    void setMap();

    /**
     * Sets sizex of map.
     */
    void setSizeX();

    /**
     * Sets sizey of map.
     */
    void setSizeY();

    /**
     * Saves game.
     */
    void saveGame();

    /**
     * Finds towers in map and calls appropriate methods for them.
     */
    void towerActions();

    /**
     * Finds enemies in map and calls appropriate methods for them.
     */
    void enemyActions();

    /**
     * Finds End/Finish points for enemies in map and calls appropriate methods for them.
     */
    void finActions();

    /**
     * Finds Spawn points in map and calls appropriate methods for them.
     */
    void startActions();


    /**
     * Paints map with for cycle calling print for elements.
     */
    void paintMap();

    /**
     * Updates info in 'Stats' window and paints it.
     */
    void paintStats();

    /**
     * Sets all fields in newmap to NULL.
     * If newmap is empty it sets is to appropriate size and sets it to NULL.
     */
    void nullNewMap();

    /**
     * Sets all fields in map to NULL.
     */
    void nullMap();

    /**
     * Fills all empty (NULL) spaces with values from map.
     */
    void fillNewMap();


    /**
     * Displays error message given in parameter 'error'.
     * @param [in] error
     */
    void displayError(string error);

    /**
     * Handles keyboard control of cursor.
     */
    void cursorControl();

    /**
     * Handles user inputs from keyboard.
     */
    void Control();

    /**
     * Builds structures depending on what user chose.
     */
    void buildStructure();

    /**
     * Copies Enemy from map to newmap.
     * If place in newmap is empty, tries to stay in place.
     * If current position is also occupied, moves there forcefully (deletes previous enemy)
     * 
     * @param [in] x new position x in newmap
     * @param [in] y new position y in newmap
     * @param [in] prevx previous position x in map
     * @param [in] prevy previous position y in map
     * @param [in] enemy pointer to the enemy that we are moving
     */
    void enemyMove(int x, int y, int prevx, int prevy, Enemy * enemy);

    /**
     * Searches for enemies in range of finish point and works with them accordingly.
     * 
     * @param [in] inx position x of Finish point in map
     * @param [in] iny position y of Finish point in map
     * @param [in] finish pointer to the Fin that we are working with
     */
    void enemyBreach(int inx, int iny, Fin * finish);

    /**
     * Spawns new enemies.
     * 
     * @param [in] inx position x of Spawn point in map
     * @param [in] iny position y of Spawn point in map
     * @param [in] start pointer to the Start that we are working with
     */
    void spawnEnemy(int inx, int iny, Start * start);

    /**
     * Randomly moves enemy enemies.
     * 
     * @param [in] x position x of enemy in map
     * @param [in] y position y of Spawn point in map
     * @param [in] enemy pointer to the Enemy that we are working with
     */
    void enemyMoveRandom(int x, int y, Enemy * enemy);

    /**
     * Processes information from BFS function and calculates next position for enemy according to BFS algorithm.
     * 
     * @param [in] inx position x of enemy in map
     * @param [in] iny position y of enemy in map
     * @param [in] enemy pointer to the Enemy that we are working with
     */
    void enemyMoveBFS(int inx, int iny, Enemy * enemy);

    /**
     * Searches for enemies to shoot.
     * Then shoots them.
     * 
     * @param [in] inx position x of tower in map
     * @param [in] iny position y of tower in map
     * @param [in] tower pointer to the Tower that we are working with
     */
    void towerShoot(int inx, int iny, Tower * tower);

    /**
     * Performs BFS algorithm search in map for Finish points.
     * 
     * @param [in] x position x of enemy in map
     * @param [in] y position y of enemy in map
     * @param [out] distance determines how far this path takes to get to Finish
     */
    int BFS(int x, int y);

    /**
     * Copies newmap on map.
     * Essentially makes recent map (newmap) into old map (map)
     */
    void copyNewMap();

    /**
     * Searches for enemies to shoot.
     * Then shoots them.
     * 
     * @param [in] i position in initmap that we are reading from
     * @param [in] row position y of current element
     * @param [in] col position x of current element
     */
    void addElement(int i, int row, int col);

    /**
     * Game cycle.
     * Stops when game has ended.
     * Calls various game methods.
     * Runs cursor control and control multiple times per one tick of game map.
     */
    void play();
    
    /**
     * Performs Dijkstra algorithm weighted search.
     * 
     * @param x
     * @param y
     * @param [out] distance to Fin
     */
    int Dijkstra(int x, int y);
    
    /**
     * Sort function needed for Dijkstra algorithm.
     * 
     * @param [in] a
     * @param [in] b
     * @param [out] bigger or smaller 
     */
    static bool sortFunc(pair<pair<int, int>, int > a, pair<pair<int, int>, int > b);
    
    /**
     * Repeated part of Dijkstra algorithm.
     * 
     * @param [in] tmpy
     * @param [in] tmpx
     * @param [in] vec  vector of weighted tiles
     * @param [in] visited  set of visited tiles
     * @param [in] distance distance from Fin
     */
    void recountDijkstra(int tmpy, int tmpx, vector < pair<pair < int, int >, int > > & vec, set < pair<int, int> > & visited,int distance);
};

#endif
