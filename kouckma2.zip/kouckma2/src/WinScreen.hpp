
#ifndef WINSCREEN_H
#define WINSCREEN_H

#include "Screen.hpp"

/**
 * This class handles showing the winning screen after game.
 */
class WinScreen : public Screen {
public:
    /**
     * Empty constructor.
     */
    WinScreen();
    /**
     * Empty destructor.
     */
    ~WinScreen();
    /**
     * Shows the actual screen with achieved score.
     * 
     * @param[in] score
     */
    void showWinScreen(int score);
};
#endif
