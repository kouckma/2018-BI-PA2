
#ifndef STATS_H
#define STATS_H

#include "Screen.hpp"
#include "Constants.hpp"

/**
 * This class handles showing the statistics like money, score and lives
 * throughout the game.
 */
class Stats : public Screen {
public:
    /**
     * score attribute of game.
     */
    int statScore = 0;
    /**
     * lives attribute of game.
     */
    int statLives = 0;
    /**
     * money attribute of game.
     */
    int statMoney = 0;
    /**
     * Empty constructor.
     */
    Stats();
    /**
     * Empty destructor.
     */
    ~Stats();
    /**
     * Shows current stats of lives score and money.
     */
    void showStats();
};
#endif
