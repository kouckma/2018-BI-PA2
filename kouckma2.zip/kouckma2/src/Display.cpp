
#include "Display.hpp"

Display::Display(string ininfo) {
    info = ininfo;
}

void Display::showDisplay() {
    mvwprintw(win, curry / 12, currx / 2 - (info.size() / 2), info.c_str());
    wrefresh(win);
    refresh();
}

Display::~Display() {
}
