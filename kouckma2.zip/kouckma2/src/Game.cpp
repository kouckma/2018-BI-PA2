
#include"Game.hpp"

Game::~Game() {
    for (int j = 0; j < sizey; j++) {
        for (int i = 0; i < sizex; i++) {
            delete map[j][i];
        }
    }
    for (int j = 0; j < sizey; j++) {
        for (int i = 0; i < sizex; i++) {
            if (newmap[j][i])delete newmap[j][i];
        }
    }
}

Game::Game(string srcMap, int inDifficulty) : difficulty(inDifficulty) {
    mapDestination = "src/maps/" + srcMap;
    gameInit();
}

Game::Game(string srcMap, string srcInit, int inDifficulty) : difficulty(inDifficulty) {
    mapDestination = "src/saved_games/maps/" + srcMap;
    statsInit(srcInit);
    gameInit();
}

void Game::statsInit(string srcInit) {

    string dest = "src/saved_games/inits/" + srcInit;
    vector<string> initVec;

    ifstream infile(dest);


    string number = "";
    while (infile.get(c)) {
        if (c == '\n') {
            initVec.push_back(number);
            number = "";
        } else number += c;
    }

    if (initVec.size() == 3) {
        lives = stoi(initVec[0]);
        score = stoi(initVec[1]);
        money = stoi(initVec[2]);
    }
}

void Game::gameInit() {
    clear();

    presetMap();

    setMap();
    statWindow = Stats();
    statWindow.createWindow(24, 12, currx / 2 - 12, (curry / 2 + sizey / 2) + 1);
    controlsWindow = ControlsScreen();
    controlsWindow.createWindow(22, 16, (currx / 2) - (sizex / 2 + 25), (curry / 2) - 7);

    Screen::createWindow(sizex, sizey, (currx / 2 - sizex / 2), (curry / 2 - sizey / 2));
    paintMap();
    srand(time(NULL));

    curs_set(TRUE);
    wmove(win, 0, 0);
    cursx = 0;
    cursy = 0;
    wrefresh(win);

    play();
}

void Game::play() {
    nodelay(stdscr, TRUE);
    int count = 0;
    int scoreToReach = difficulty * 1000;

    while (!ended) {
        if ((input = getch()) == ERR) {

        } else {
            cursorControl();
            Control();
            wrefresh(win);
            refresh();
            paintMap();
            continue;
        }
        if (count % 100 == 0) {

            if (count % 500 == 0) {
                if (errorUP) {
                    clear();
                    errorUP = 0;
                }
                count = 0;
            }
            score += 2;
            money++;

            //  All actions must be in this order
            //  Finish actions
            finActions();
            //  Start/Spawn actions
            startActions();
            //  Tower actions
            towerActions();
            //  Enemy actions
            enemyActions();

            fillNewMap();
            copyNewMap();
            paintMap();
            paintStats();
            controlsWindow.showControlsScreen();
            nullNewMap();
        }
        count++;
        wmove(win, cursy, cursx);
        wrefresh(win);
        usleep(4000);

        if (score >= scoreToReach) {
            won = 1;
            ended = 1;
        }
    }
    if (won) {
        WinScreen winScreen = WinScreen();
        winScreen.createWindow(currx, curry);
        winScreen.showWinScreen(score);
    } else {
        LooseScreen looseScreen = LooseScreen();
        looseScreen.createWindow(currx, curry);
        looseScreen.showLooseScreen(score);
    }
}

void Game::towerActions() {
    for (int j = 0; j < sizey; j++) {
        for (int i = 0; i < sizex; i++) {
            if (map[j][i]->type == TOWER) {
                Tower * tower = dynamic_cast<Tower *> (map[j][i]);
                towerShoot(map[j][i]->x, map[j][i]->y, tower);
                tower->event();
            }
        }
    }
}

void Game::enemyActions() {
    for (int j = 0; j < sizey; j++) {
        for (int i = 0; i < sizex; i++) {
            if (map[j][i]->type == ENEMY) {
                Enemy * enemy = dynamic_cast<Enemy *> (map[j][i]);
                if (enemy->isStunned()) enemyMove(i, j, i, j, enemy);
                else enemyMoveBFS(map[j][i]->x, map[j][i]->y, enemy);
            }
        }
    }
}

void Game::finActions() {
    for (int j = 0; j < sizey; j++) {
        for (int i = 0; i < sizex; i++) {
            if (map[j][i]->type == FIN) {
                Fin * finish = dynamic_cast<Fin *> (map[j][i]);
                enemyBreach(i, j, finish);
            }
        }
    }
}

void Game::startActions() {
    for (int j = 0; j < sizey; j++) {
        for (int i = 0; i < sizex; i++) {
            if (map[j][i]->type == START) {
                Start * start = dynamic_cast<Start *> (map[j][i]);
                if (spawnUP)spawnEnemy(i, j, start);
            }
        }
    }
}

void Game::paintStats() {
    getyx(win, cursy, cursx);

    statWindow.statLives = lives;
    statWindow.statScore = score;
    statWindow.statMoney = money;
    statWindow.showStats();

    wmove(win, cursy, cursx);
    wrefresh(win);
    refresh();
}

void Game::cursorControl() {
    getyx(win, cursy, cursx);

    switch (input) {
        case 'w':
            wmove(win, cursy - 1, cursx);
            break;
        case 's':
            wmove(win, cursy + 1, cursx);
            break;
        case 'a':
            wmove(win, cursy, cursx - 1);
            break;
        case 'd':
            wmove(win, cursy, cursx + 1);
            break;
        default:
            break;
    }
    getyx(win, cursy, cursx);
    wrefresh(win);
    refresh();
}

void Game::Control() {
    getyx(win, cursy, cursx);
    switch (input) {
        case 'e':
            buildStructure();
            break;
        case '1':
            chosen = WALL;
            break;
        case '2':
            chosen = STUN;
            break;
        case '3':
            chosen = BASIC;
            break;
        case '4':
            chosen = UPGRADED;
            break;
        case 'f':
            if (spawnUP)spawnUP = 0;
            else spawnUP = 1;
            break;
        case 'r':
            saveGame();
        case 'c':
            clear();
        default:
            break;
    }
    wmove(win, cursy, cursx);
    wrefresh(win);
    refresh();
}

void Game::saveGame() {
    SaveScreen savescreen = SaveScreen();
    savescreen.createWindow(currx, curry);
    string userInput = savescreen.getInput();
    ofstream outmap("src/saved_games/maps/" + userInput);
    for (int j = 0; j < sizey; j++) {
        for (int i = 0; i < sizex; i++) {
            outmap << map[j][i]->getChar();
        }
        outmap << '\n';
    }
    ofstream outinit("src/saved_games/inits/" + userInput);
    outinit << lives << endl;
    outinit << score << endl;
    outinit << money << endl;
}

void Game::displayError(string error) {
    Display err = Display(error);
    err.createWindow(currx, curry / 10);
    err.showDisplay();
    errorUP = 1;
}

void Game::buildStructure() {

    if (chosen == WALL) {
        if (map[cursy][cursx]->type == GROUND) {
            if (money >= WALLCOST) {
                delete map[cursy][cursx];
                Wall * newel = new Wall(cursx, cursy);
                map[cursy][cursx] = newel;
                money -= WALLCOST;
            } else {
                displayError("Not enough money. \n");
            }

        } else {
            displayError("You cant place a wall here \n");
        }
    } else if (chosen == STUN || chosen == UPGRADED || chosen == BASIC) {
        if (map[cursy][cursx]->type == WALL) {
            if (chosen == STUN) {
                if (money >= STUNCOST) {
                    delete map[cursy][cursx];
                    StunTower * newel = new StunTower(cursx, cursy);
                    map[cursy][cursx] = newel;
                    money -= STUNCOST;
                } else {
                    displayError("Not enough money. \n");
                }
            } else if (chosen == UPGRADED) {
                if (money >= UPGRADEDCOST) {
                    delete map[cursy][cursx];
                    UpgradedTower * newel = new UpgradedTower(cursx, cursy);
                    map[cursy][cursx] = newel;
                    money -= UPGRADEDCOST;
                } else {
                    displayError("Not enough money. \n");
                }

            } else if (chosen == BASIC) {
                if (money >= BASICCOST) {
                    delete map[cursy][cursx];
                    BasicTower * newel = new BasicTower(cursx, cursy);
                    map[cursy][cursx] = newel;
                    money -= BASICCOST;
                } else {
                    displayError("Not enough money. \n");
                }

            }
        } else {
            Display err = Display("You cant place a tower here \n");
            err.createWindow(currx, curry / 10);
            err.showDisplay();
            errorUP = 1;
        }
    }
}

void Game::enemyBreach(int inx, int iny, Fin* finish) {
    for (int j = iny - 1; j <= iny + 1; j++) {
        for (int i = inx - 1; i <= inx + 1; i++) {
            if ((j >= 0 && j < sizey) && (i >= 0 && i < sizex)) {
                if (map[j][i]->type == ENEMY) {
                    if (lives - 1 <= 0) {
                        ended = 1;
                        j = iny + 2;
                        break;
                    } else {
                        delete map[j][i];
                        Ground * newel = new Ground(i, j);
                        map[j][i] = newel;
                        lives--;
                    }
                }
            }
        }
    }
}

void Game::spawnEnemy(int inx, int iny, Start* start) {
    int r = (rand() * rand() + rand()) % 7;


    for (int j = iny - 1; j <= iny + 1; j++) {
        for (int i = inx - 1; i <= inx + 1; i++) {
            if ((j >= 0 && j < sizey) && (i >= 0 && i < sizex)) {
                if (map[j][i]->type == GROUND) {
                    if (r < -1) {
                        delete map[j][i];
                        Mob * newel = new Mob(i, j);
                        map[j][i] = newel;
                    } else if (r > 5) {
                        delete map[j][i];
                        Boss * newel = new Boss(i, j);
                        map[j][i] = newel;
                    }
                    j = iny + 2;
                    break;
                }
            }
        }
    }
}

void Game::towerShoot(int inx, int iny, Tower* tower) {
    int reach = tower->reach;

    if (tower->cooldown == 0) {
        tower->setCooldown();
        for (int j = iny - reach; j <= iny + reach; j++) {
            for (int i = inx - reach; i <= inx + reach; i++) {
                if ((j >= 0 && j < sizey) && (i >= 0 && i < sizex)) {
                    if (map[j][i]->type == ENEMY) {
                        Enemy * enemy = dynamic_cast<Enemy *> (map[j][i]);
                        if (enemy->getHealth() <= tower->damage) {
                            score += 10;
                            money += enemy->getBounty();
                            delete map[j][i];
                            Ground * newel = new Ground(i, j);
                            map[j][i] = newel;
                        } else {
                            enemy->getShot(tower->damage, tower->hasStun);
                        }
                        j = iny + reach + 1;
                        break;
                    }
                }
            }
        }
    }
}

void Game::enemyMove(int x, int y, int prevx, int prevy, Enemy * enemy) {

    Element * newEnemy = enemy->clone();

    if (!newmap[y][x]) {
        newmap[y][x] = newEnemy;
        newmap[y][x]->setXY(x, y);

    } else if (!newmap[prevy][prevx]) {
        newmap[prevy][prevx] = newEnemy;
    } else {
        delete newmap[prevy][prevx];
        newmap[prevy][prevx] = newEnemy;
    }
    newEnemy->event();
}

void Game::enemyMoveRandom(int x, int y, Enemy * enemy) {

    int r = (rand() * rand() + rand()) % 4;

    if (r == 0) {
        if (map[y + 1][x]->type == GROUND || map[y + 1][x]->type == ENEMY)enemyMove(x, y + 1, x, y, enemy);
        else enemyMove(x, y, x, y, enemy);
    } else if (r == 1 || r == -1) {
        if (map[y - 1][x]->type == GROUND || map[y - 1][x]->type == ENEMY) enemyMove(x, y - 1, x, y, enemy);
        else enemyMove(x, y, x, y, enemy);
    } else if (r == 2 || r == -2) {
        if (map[y][x + 1]->type == GROUND || map[y][x + 1]->type == ENEMY) enemyMove(x + 1, y, x, y, enemy);
        else enemyMove(x, y, x, y, enemy);
    } else if (r == 3 || r == -3) {
        if (map[y][x - 1]->type == GROUND || map[y][x - 1]->type == ENEMY) enemyMove(x - 1, y, x, y, enemy);
        else enemyMove(x, y, x, y, enemy);
    }
}

void Game::enemyMoveBFS(int x, int y, Enemy * enemy) {

    int up = -1, right = -1, down = -1, left = -1;

    if (map[y + 1][x]->type == GROUND || map[y + 1][x]->type == ENEMY) {
        if (enemy->enemytype == MOB) down = Dijkstra(x, y + 1);
        else down = BFS(x, y + 1);
    }
    if (map[y - 1][x]->type == GROUND || map[y - 1][x]->type == ENEMY) {
        if (enemy->enemytype == MOB) up = Dijkstra(x, y - 1);
        else up = BFS(x, y - 1);
    }
    if (map[y][x + 1]->type == GROUND || map[y][x + 1]->type == ENEMY) {
        if (enemy->enemytype == MOB) right = Dijkstra(x + 1, y);
        else right = BFS(x + 1, y);
    }
    if (map[y][x - 1]->type == GROUND || map[y][x - 1]->type == ENEMY) {
        if (enemy->enemytype == MOB) left = Dijkstra(x - 1, y);
        else left = BFS(x - 1, y);
    }

    if (down != -1 && (down <= up || up == -1) && (down <= right || right == -1)&& (down <= left || left == -1))
        enemyMove(x, y + 1, x, y, enemy);
    else if (up != -1 && (up <= down || down == -1) && (up <= right || right == -1)&& (up <= left || left == -1))
        enemyMove(x, y - 1, x, y, enemy);
    else if (right != -1 && (right <= up || up == -1) && (right <= down || down == -1)&& (right <= left || left == -1))
        enemyMove(x + 1, y, x, y, enemy);
    else if (left != -1 && (left <= up || up == -1) && (left <= right || right == -1)&& (left <= down || down == -1))
        enemyMove(x - 1, y, x, y, enemy);
    else
        enemyMove(x, y, x, y, enemy);
}

bool Game::sortFunc(pair<pair<int, int>, int > a, pair<pair<int, int>, int > b) {
    return (a.second) > (b.second);
}

int Game::Dijkstra(int inx, int iny) {
    int x = inx;
    int y = iny;
    pair < int, int > position;
    int distance = 1;
    vector < pair<pair < int, int >, int > > vec;
    set < pair<int, int> > visited;
    position = make_pair(x, y);

    visited.insert(position);
    vec.push_back(make_pair(position, distance));

    while (!vec.empty()) {
        sort(vec.begin(), vec.end(), Game::sortFunc);

        position = vec.back().first;
        distance = vec.back().second;
        x = position.first;
        y = position.second;
        vec.pop_back();

        for (int j = y - 1; j <= y + 1; j++) {
            for (int i = x - 1; i <= x + 1; i++) {
                if ((j >= 0 && j < sizey) && (i >= 0 && i < sizex)) {
                    if (map[j][i]->type == TOWER) {
                        distance += 1000;
                    }
                }
            }
        }

        if (map[y + 1][x]->type == FIN) {
            return distance + 1;
        } else if (map[y - 1][x]->type == FIN) {
            return distance + 1;
        } else if (map[y][x + 1]->type == FIN) {
            return distance + 1;
        } else if (map[y][x - 1]->type == FIN) {
            return distance + 1;
        }
        // ===========================================================
        int tmpx, tmpy;

        tmpx = x;
        tmpy = y + 1;
        recountDijkstra(tmpy, tmpx, vec, visited, distance);

        tmpx = x;
        tmpy = y - 1;
        recountDijkstra(tmpy, tmpx, vec, visited, distance);

        tmpx = x + 1;
        tmpy = y;
        recountDijkstra(tmpy, tmpx, vec, visited, distance);

        tmpx = x - 1;
        tmpy = y;
        recountDijkstra(tmpy, tmpx, vec, visited, distance);
    }
    return -1;
}

void Game::recountDijkstra(int tmpy, int tmpx, vector < pair<pair < int, int >, int > > & vec, set < pair<int, int> > & visited, int distance) {
    vector < pair<pair<int, int>, int> >::iterator found;

    if (map[tmpy][tmpx]->type == GROUND || map[tmpy][tmpx]->type == ENEMY) {
        if (visited.count(make_pair(tmpx, tmpy)) != 0) {

            for (found = vec.begin(); found != vec.end(); ++found) {
                if ((*found).first.first == tmpx && (*found).first.second == tmpy) {
                    if ((*found).second > distance + 1) {
                        (*found).second = distance + 1;
                        break;
                    }
                }
            }
        } else {
            vec.push_back((make_pair(make_pair(tmpx, tmpy), distance + 1)));
            visited.insert((make_pair(tmpx, tmpy)));
        }
    }
}

int Game::BFS(int inx, int iny) {
    int x = inx;
    int y = iny;
    pair < int, int > position;
    int distance = 0;
    queue < pair<pair < int, int >, int> > que;
    set < pair<int, int> > visited;

    position = make_pair(x, y);
    visited.insert(position);
    que.push(make_pair(position, distance));

    while (!que.empty()) {
        position = que.front().first;
        distance = que.front().second;
        x = position.first;
        y = position.second;
        que.pop();

        if (map[y + 1][x]->type == FIN) {
            return distance + 1;
        } else if (map[y - 1][x]->type == FIN) {
            return distance + 1;
        } else if (map[y][x + 1]->type == FIN) {
            return distance + 1;
        } else if (map[y][x - 1]->type == FIN) {
            return distance + 1;
        }
        // ===========================================================
        if ((map[y + 1][x]->type == GROUND || map[y + 1][x]->type == ENEMY) && visited.count(make_pair(x, y + 1)) == 0) {
            que.push(make_pair(make_pair(x, y + 1), distance + 1));
            visited.insert((make_pair(x, y + 1)));
        }
        if ((map[y - 1][x]->type == GROUND || map[y - 1][x]->type == ENEMY) && visited.count(make_pair(x, y - 1)) == 0) {
            que.push(make_pair(make_pair(x, y - 1), distance + 1));
            visited.insert((make_pair(x, y - 1)));
        }
        if ((map[y][x + 1]->type == GROUND || map[y][x + 1]->type == ENEMY) && visited.count(make_pair(x + 1, y)) == 0) {
            que.push(make_pair(make_pair(x + 1, y), distance + 1));
            visited.insert((make_pair(x + 1, y)));
        }
        if ((map[y][x - 1]->type == GROUND || map[y][x - 1]->type == ENEMY) && visited.count(make_pair(x - 1, y)) == 0) {
            que.push(make_pair(make_pair(x - 1, y), distance + 1));
            visited.insert((make_pair(x - 1, y)));
        }
    }
    return -1;
}

void Game::fillNewMap() {
    for (int j = 0; j < sizey; j++) {
        for (int i = 0; i < sizex; i++) {
            if (newmap[j][i]) {
            } else if (!newmap[j][i]) {
                if (map[j][i]->type == ENEMY) {
                    Ground * newel = new Ground(i, j);
                    newmap[j][i] = newel;
                } else if (map[j][i]->type == WALL) {
                    Wall * newel = new Wall(i, j);
                    newmap[j][i] = newel;
                } else if (map[j][i]->type == START) {
                    Start * newel = new Start(i, j);
                    newmap[j][i] = newel;
                } else if (map[j][i]->type == FIN) {
                    Fin * newel = new Fin(i, j);
                    newmap[j][i] = newel;
                } else if (map[j][i]->type == TOWER) {
                    Element * newel = map[j][i]->clone();
                    newmap[j][i] = newel;
                } else if (map[j][i]->type == GROUND) {
                    Ground * newel = new Ground(i, j);
                    newmap[j][i] = newel;
                } else {

                    Wall * newel = new Wall(i, j);
                    newmap[j][i] = newel;
                }
            }
        }
    }
}

void Game::nullNewMap() {
    //init newmap
    if (!newMapIsSet) {
        for (int j = 0; j < sizey; j++) {
            for (int i = 0; i < sizex; i++) {
                newmap[j].push_back(NULL);
            }
        }
        newMapIsSet = 1;
    } else {
        for (int j = 0; j < sizey; j++) {
            for (int i = 0; i < sizex; i++) {

                newmap[j][i] = NULL;
            }
        }
    }
}

void Game::nullMap() {
    //init map
    for (int j = 0; j < sizey; j++) {
        for (int i = 0; i < sizex; i++) {

            map[j].push_back(NULL);
        }
    }
}

void Game::copyNewMap() {
    for (int j = 0; j < sizey; j++) {
        for (int i = 0; i < sizex; i++) {
            delete map[j][i];
        }
    }
    for (int j = 0; j < sizey; j++) {
        for (int i = 0; i < sizex; i++) {

            map[j][i] = newmap[j][i];
        }
    }
}

void Game::paintMap() {

    getyx(win, cursy, cursx);

    for (int j = 0; j < sizey; j++) {
        for (int i = 0; i < sizex; i++) {

            wmove(win, j, i);
            map[j][i]->print(win);
        }
        mvwaddch(win, j, sizex, '\n');
        wrefresh(win);
    }

    wmove(win, cursy, cursx);
    getyx(win, cursy, cursx);

    wrefresh(win);
}

void Game::presetMap() {
    ifstream infile(mapDestination);

    while (infile.get(c)) {

        initmap.push_back(c);
    }
    setSizeX();
    setSizeY();
}

void Game::setSizeX() {
    for (int i = 0; (unsigned) i < initmap.size(); i++) {
        if (initmap[i] == '\n') {
            sizex = i;

            break;
        }
    }
}

void Game::setSizeY() {
    for (int i = 0; (unsigned) i < initmap.size(); i++) {
        if (initmap[i] == '\n') {

            sizey++;
        }
    }
}

void Game::setMap() {
    map.resize(sizey);
    newmap.resize(sizey);
    nullNewMap();
    nullMap();
    int n = 0, x = 0;
    for (int i = 0; (unsigned) i < initmap.size(); i++) {
        addElement(i, n, x);
        x++;
        if (initmap[i] == '\n') {

            n++;
            x = 0;
        }
    }
}

//  adds elements on initialization

void Game::addElement(int i, int row, int col) {
    switch (initmap[i]) {
        case '#':
        {
            Wall * newel = new Wall(col, row);
            map[row][col] = newel;
        }
            break;
        case '<':
        {
            if (initmap.size() > (unsigned) (i + 1) && (initmap[i + 1] == '=' || initmap[i + 1] == '#')) {
                Start * newel = new Start(col, row);
                map[row][col] = newel;
            } else if (i > 0 && (initmap[i - 1] == '=' || initmap[i - 1] == '#')) {
                Fin * newel = new Fin(col, row);
                map[row][col] = newel;
            } else break;
        }
            break;
        case '.':
        {
            Ground * newel = new Ground(col, row);
            map[row][col] = newel;
        }
            break;
        case '@':
        {
            Mob * newel = new Mob(col, row);
            map[row][col] = newel;
        }
            break;
        case '0':
        {
            Boss * newel = new Boss(col, row);
            map[row][col] = newel;
        }
            break;
        case 'B':
        {
            BasicTower * newel = new BasicTower(col, row);
            map[row][col] = newel;
        }
            break;
        case 'A':
        {
            UpgradedTower * newel = new UpgradedTower(col, row);
            map[row][col] = newel;
        }
            break;
        case 'S':
        {
            StunTower * newel = new StunTower(col, row);
            map[row][col] = newel;
        }
            break;
        case '=':
        {
            Wall * newel = new Wall(col, row);
            map[row][col] = newel;
        }
            break;
        default:
            break;
    }
}


