
#include "SaveScreen.hpp"

SaveScreen::SaveScreen() {
}

SaveScreen::~SaveScreen() {
}

string SaveScreen::getInput() {
    int inputc;
    string save;
    mvwprintw(win, curry / 2, currx / 2 - 20, "  Write down name of your save and press ENTER.\n");
    mvwprintw(win, curry / 2 + 1, currx / 2 - 20, "===================================================\n");
    mvwprintw(win, curry / 2 + 3, currx / 2 - 20, "===================================================\n");
    wrefresh(win);
    refresh();
    echo();
    wmove(win, curry / 2 + 2, currx / 2 - 20);
    while (1) {
        inputc = wgetch(win);
        if (inputc == 10)break;
        save += ((char) inputc);
    }
    refresh();
    wrefresh(win);
    noecho();
    clear();
    return save;
}