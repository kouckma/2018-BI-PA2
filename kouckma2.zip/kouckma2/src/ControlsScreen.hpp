
#ifndef CONTROLS_H
#define CONTROLS_H

#include "Screen.hpp"

/**
 * Info class showing controls.
 */
class ControlsScreen : public Screen {
public:
    /**
     * Empty constructor.
     */
    ControlsScreen();
    /**
     * Empty destructor.
     */
    ~ControlsScreen();
    /**
     * Shows Controls.
     */
    void showControlsScreen();
};
#endif
