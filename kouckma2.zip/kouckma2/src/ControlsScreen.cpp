
#include "ControlsScreen.hpp"

ControlsScreen::ControlsScreen() {
}

void ControlsScreen::showControlsScreen() {
    wprintw(win, "  =================\n");
    wprintw(win, "     --CONTROLS--\n");
    wprintw(win, "  PURPOSE    | KEY\n");
    wprintw(win, "  =================\n");
    wprintw(win, "  UP         | -w-\n");
    wprintw(win, "  LEFT       | -a-\n");
    wprintw(win, "  DOWN       | -s-\n");
    wprintw(win, "  RIGHT      | -d-\n");
    wprintw(win, "  BUILD      | -e-\n");
    wprintw(win, "  SAVE GAME  | -r-\n");
    wprintw(win, "  =================\n");
    wprintw(win, "        CHEAT\n");
    wprintw(win, "  =================\n");
    wprintw(win, "  STOP-SPAWN | -f-\n");
    box(win, 0, 0);
    wrefresh(win);
    refresh();
}

ControlsScreen::~ControlsScreen() {
}

