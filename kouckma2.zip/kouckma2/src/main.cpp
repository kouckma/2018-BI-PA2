#include <ncurses.h>

#include "Menus/MainMenu.hpp"

using namespace std;

int main(int argc, char** argv) {

    initscr();
    noecho();
    refresh();
    curs_set(FALSE);

    MainMenu().showMenu();


    echo();
    endwin();



    return 0;
}
