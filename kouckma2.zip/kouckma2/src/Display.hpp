
#ifndef DISPLAY_H
#define DISPLAY_H

#include "Screen.hpp"

/**
 * Shows various errors (and other one-line messages).
 */
class Display : public Screen {
protected:
    /**
     * displayed message.
     */
    string info;
public:
    /**
     * Constructor that sets info to ininfo value.
     * 
     * @param [in] ininfo message that we want to display
     */
    Display(string ininfo);
    /**
     * Empty destructor.
     */
    ~Display();
    /**
     * Shows the message from variable info.
     */
    void showDisplay();
};
#endif
