
#ifndef CONSTANTS_H
#define CONSTANTS_H

/**
 * Prices of buildings.
 */
#define WALLCOST 100
#define STUNCOST 20
#define BASICCOST 10
#define UPGRADEDCOST 40

/**
 * Towers damages.
 */
#define STUNDAMAGE 50
#define BASICDAMAGE 100
#define UPGRADEDDAMAGE 400

/**
 * Towers cooldowns.
 */
#define STUNCOOLDOWN 3
#define BASICCOOLDOWN 2
#define UPGRADEDCOOLDOWN 3

/**
 * Enemies HPs.
 */
#define MOBHP 150
#define BOSSHP 500

/**
 * Enemies gold bounties.
 */
#define BOSSBOUNTY 20
#define MOBBOUNTY 5

/**
 * Player init values.
 */
#define STARTGOLD 1000
#define STARTLIVES 10


/**
 * Game constants.
 */
#define WALL 1
#define TOWER 6
#define ENEMY 5
#define START 2
#define FIN 3
#define GROUND 4


#define STUN 2
#define BASIC 3
#define UPGRADED 4

#define MOB 1
#define BOSS 2

#define PHASETIME 100




#endif