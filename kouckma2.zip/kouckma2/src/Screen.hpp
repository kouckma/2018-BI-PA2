#ifndef SCREEN_H
#define SCREEN_H

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <ncurses.h>
#include <vector>

#include <unistd.h>
#include<time.h>


using namespace std;

/**
 * Parent class used for screen positioning of various elements.
 */
class Screen {
protected:
    /**
     * ncurses window.
     */
    WINDOW * win;

public:
    /**
     * width and height of current TERMINAL window (not this->win).
     */
    int currx, curry;

    /**
     * starting x and y positions of window.
     */
    int posx, posy;
    Screen(void);
    /**
     * Creates window.
     * 
     * @param[in] x width
     * @param[in] y height
     * @param[in] posx starting x position on terminal window
     * @param[in] posy starting y position on terminal window
     */
    virtual void createWindow(int x = 10, int y = 10, int posx = 0, int posy = 0);
    /**
     * Empty destructor.
     */
    virtual ~Screen();
};
#endif
