#ifndef LOOSESCREEN_H
#define LOOSESCREEN_H

#include "Screen.hpp"

/**
 * This class handles showing the loosing screen after game.
 */
class LooseScreen : public Screen {
public:
    /**
     * Empty constructor.
     */
    LooseScreen();
    /**
     * Empty destructor.
     */
    ~LooseScreen();
    /**
     * Shows the actual screen with achieved score.
     * 
     * @param[in] score
     */
    void showLooseScreen(int inScore);
};
#endif
