#include"LoadGame.hpp"

LoadGame::LoadGame(void) {
    Screen::createWindow(currx, curry);
}

LoadGame::~LoadGame(void) {
}

void LoadGame::handle() {
    string path = "";
    mvwprintw(win, hy, hx - 20, "Write down path to your saved game and press ENTER.\n");
    mvwprintw(win, hy + 1, hx - 20, "===================================================\n");
    mvwprintw(win, hy + 3, hx - 20, "===================================================\n");
    wrefresh(win);
    refresh();
    echo();
    wmove(win, hy + 2, hx - 20);
    while (1) {
        inputc = wgetch(win);
        if (inputc == 10)break;
        path += ((char) inputc);
    }
    refresh();
    wrefresh(win);
    noecho();

    ifstream initSrc("src/saved_games/inits/" + path);
    ifstream mapSrc("src/saved_games/maps/" + path);
    if (initSrc.fail() || mapSrc.fail()) {
        mvwprintw(win, curry / 2 - 5, hx - 5, "Save doesnt exist.");
        mvwprintw(win, curry / 2 - 4, hx - 10, "--Press any key to continue--");
        refresh();
        wrefresh(win);
        getch();
        wclear(win);
        handle();
    } else {

        Game(path, path);

        MainMenu().showMenu();
    }
}
