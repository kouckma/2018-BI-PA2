
#ifndef MENU_H
#define MENU_H

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <ncurses.h>
#include <vector>

#include "../Screen.hpp"
#include "../Game.hpp"


using namespace std;

/**
 * Parent class used for displaying items in the form of menu.
 */
class Menu : public Screen {
protected:
    /**
     * options of menu.
     */
    vector <string> options;
    /**
     * if this is set, user can acces NewGame option.
     */
    string mapsource;
    /**
     * determines if valid mapsource is set.
     */
    int mapLoaded = 0;
    /**
     * index of choice in menu.
     */
    int index = 0;
    /**
     * user input from keyboard.
     */
    int inputc;
    /**
     * half of current screen Y and X values for easier positioning.
     * set in initBox
     */
    int hx, hy;

public:
    /**
     * Empty constructor.
     */
    Menu(void);
    /**
     * Empty destructor.
     */
    virtual ~Menu();
    /**
     * Shows menu and allows to browse and select items.
     */
    virtual void showMenu();
    /**
     * Called after user chooses an item from menu.
     */
    virtual void handle();
    /**
     * Sets up box around screen.
     */
    virtual void initBox();
    /**
     * Sets map source and checks validity of file.
     */
    virtual void setMapSource(const string source);
protected:
    /**
     * Controls movement in menu from keyboard input.
     */
    virtual void menuMovementControl();
};

#endif
