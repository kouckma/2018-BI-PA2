#ifndef LOADGAME_H
#define LOADGAME_H

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <ncurses.h>
#include <vector>

#include "Menu.hpp"
#include "MainMenu.hpp"

/**
 * Class handling user input of valid saved game, then calling Game instance
 */
class LoadGame : public Menu {
public:
    /**
     * Constructor that creates new window.
     */
    LoadGame(void);
    /**
     * Empty destructor.
     */
    ~LoadGame(void);
    /**
     * Called after user hits ENTER in menu.
     * Handles user input to search for given destination of map and init file.
     * Validates both files location.
     */
    void handle();
};

#endif