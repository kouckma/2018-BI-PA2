#include"NewGame.hpp"

void NewGame::fillVec() {
    options.push_back("Easy");
    options.push_back("Normal");
    options.push_back("Hard");
}

NewGame::NewGame(void) {
    Screen::createWindow(currx, curry);
    fillVec();
}

NewGame::~NewGame(void) {
}

void NewGame::handle() {
    switch (index) {
        case 0:
            Game(mapsource.c_str(), 1);
            break;
        case 1:
            Game(mapsource.c_str(), 3);
            break;
        case 2:
            Game(mapsource.c_str(), 5);
            break;
        default:
            break;
    }
    MainMenu().showMenu();
}
