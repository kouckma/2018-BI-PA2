#ifndef NEWGAME_H
#define NEWGAME_H

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <ncurses.h>
#include <vector>

#include "Menu.hpp"
#include"MainMenu.hpp"

/**
 * Creates new game with chosen difficulty.
 */
class NewGame : public Menu {
public:
    /**
     * Constructor that creates new window.
     */
    NewGame(void);
    /**
     * Empty destructor.
     */
    ~NewGame(void);
    /**
     * Called after user hits ENTER in menu.
     * Creates new game with chosen difficulty.
     */
    void handle();
    /**
     * Fills vector in Menu with custom items/difficulties.
     */
    void fillVec();
};

#endif