#ifndef MAINMENU_H
#define MAINMENU_H

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <ncurses.h>
#include <vector>


#include "Menu.hpp"

#include "LoadGame.hpp"
#include "LoadMap.hpp"
#include "NewGame.hpp"


/**
 * Class handling movement in menu and user choices
 */
class MainMenu : public Menu {
public:
    /**
     * Constructor that creates a window.
     */
    MainMenu(void);
    /**
     * Empty destructor.
     */
    ~MainMenu(void);
    /**
     * Called after user hits ENTER in menu.
     * Creates new instance of Menu dependent on users choice.
     */
    void handle();
    /**
     * Fills vector with options.
     */
    void fillVec();
};

#endif
