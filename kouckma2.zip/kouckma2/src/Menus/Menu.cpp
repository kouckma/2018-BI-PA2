

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <ncurses.h>
#include <vector>

#include "Menu.hpp"

Menu::Menu(void) {
}

Menu::~Menu() {
}

void Menu::handle() {
}

void Menu::initBox() {
    box(win, 0, 0);
    refresh();
    wrefresh(win);
    curs_set(FALSE);
    keypad(win, TRUE);
    hx = (currx / 2) - 5, hy = (curry / 2) - 2;
}

void Menu::showMenu() {
    initBox();
    while (options.size()) {
        for (int i = 0; (unsigned) i < options.size(); i++) {
            if (i == index) wattron(win, A_REVERSE);
            mvwprintw(win, i + hy, hx, options[i].c_str());
            wattroff(win, A_REVERSE);
        }
        refresh();
        wrefresh(win);
        inputc = wgetch(win);
        menuMovementControl();

        if (inputc == 10)break; //10 is for ENTER key
    }
    handle();
}

void Menu::setMapSource(const string source) {
    mapsource = source;
    initBox();
    ifstream infile("src/maps/" + mapsource);
    if (infile.fail()) {
        mvwprintw(win, 4, hx - 5, "File doesnt exist.");
    } else {
        mapLoaded = 1;
        initBox();
        mvwprintw(win, 4, hx - 5, "Map has been loaded.");
    }
    wrefresh(win);
    showMenu();
}

void Menu::menuMovementControl(void) {
    switch (inputc) {
        case KEY_UP:
            if (index > 0)index--;
            break;
        case KEY_DOWN:
            if ((unsigned) index + 1 < options.size())index++;
            break;
        default:
            break;
    }
}
