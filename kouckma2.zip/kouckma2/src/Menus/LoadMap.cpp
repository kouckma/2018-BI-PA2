
#include"LoadMap.hpp"

LoadMap::LoadMap(void) {
    Screen::createWindow(currx, curry);
}

LoadMap::~LoadMap(void) {
}

void LoadMap::handle() {
    mvwprintw(win, hy, hx - 20, "  Write down name of the map and press ENTER.\n");
    mvwprintw(win, hy + 1, hx - 20, "===================================================\n");
    mvwprintw(win, hy + 3, hx - 20, "===================================================\n");
    wrefresh(win);
    refresh();
    echo();
    wmove(win, hy + 2, hx - 20);
    while (1) {
        inputc = wgetch(win);
        if (inputc == 10)break;
        path += ((char) inputc);
    }
    refresh();
    wrefresh(win);
    noecho();
    MainMenu().setMapSource(path);
}
