#include "MainMenu.hpp"

void MainMenu::fillVec() {
    options.push_back("Load Map");
    options.push_back("New Game");
    options.push_back("Load Game");
    options.push_back("Quit");
}

MainMenu::MainMenu(void) {
    Screen::createWindow(currx, curry);
    fillVec();
}

MainMenu::~MainMenu(void) {
}

void MainMenu::handle() {
    switch (index) {
        case 0: LoadMap().showMenu();
            break;
        case 1:
            if (mapLoaded)NewGame().setMapSource(mapsource);
            else MainMenu().showMenu();
            break;
        case 2: LoadGame().showMenu();
            break;
        case 3:
            break;
    }
}
