#ifndef LOADMAP_H
#define LOADMAP_H


#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <ncurses.h>
#include <vector>

#include "Menu.hpp"
#include "MainMenu.hpp"

/**
 * Class handling user input of valid map location, then returning to MainMenu.
 */
class LoadMap : public Menu {
    /**
     * user-given path to map destination
     */
    string path;
public:
    /**
     * Constructor that creates new window.
     */
    LoadMap(void);
    /**
     * Empty destructor.
     */
    ~LoadMap(void);
    /**
     * Called after user hits ENTER in menu.
     * Handles user input to search for given map.
     */
    void handle();
};

#endif
