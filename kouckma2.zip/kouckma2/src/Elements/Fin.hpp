
#include"Element.hpp"

/**
 * game element Fin
 */
class Fin : public Element {
public:
    /**
     * Constructor
     * 
     * @param [in] inX horizontal position of element
     * @param [in] inY vertical position of element
     * @param [in] intype type of element
     */
    Fin(int inX, int inY, int intype = FIN);
    /**
     * Empty destructor
     */
    ~Fin();
    /**
     * Clones element.
     * 
     * @param [out] new Element
     */
    Element * clone();
    /**
     * Prints element to given window.
     * 
     * @param [in] win
     */
    void print(WINDOW * win);
    /**
     * Acts out event of Element, which may change depending on given Element
     */
    void event();
    /**
     * Gets char representing this Element.
     * 
     * @param [out] char
     */
    char getChar();
};
