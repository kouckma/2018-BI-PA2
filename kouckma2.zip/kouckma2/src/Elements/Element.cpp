
#include"Element.hpp"

Element::Element(int inX, int inY, int intype) {
    x = inX;
    y = inY;
    type = intype;
}

Element::~Element() {
}

void Element::print(WINDOW * win) {
}

void Element::event() {
}

char Element::getChar() {
    return '#';
}

Element * Element::clone() {
    return NULL;
}

void Element::setXY(int inx, int iny) {
    x = inx;
    y = iny;
}
