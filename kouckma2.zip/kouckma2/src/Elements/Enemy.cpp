

#include"Enemy.hpp"
#include"Ground.hpp"

char Enemy::getChar() {
    return 'E';
}

void Enemy::event() {
    stunned = 0;
}

Enemy::Enemy(int inX, int inY, int inHealth, int intype)
: Element(inX, inY, intype) {
    health = inHealth;
}

Enemy::~Enemy() {
}

void Enemy::print(WINDOW * win) {
    waddch(win, 'E');
    refresh();
}

void Enemy::getShot(int damage, int inStun) {
    health -= damage;
    if (inStun == 1)stunned = 1;
}

Element * Enemy::clone() {
    return new Enemy(*this);
}

int Enemy::getHealth() {
    return health;
}

int Enemy::getBounty() {
    return bounty;
}

int Enemy::isStunned() {
    return stunned;
}