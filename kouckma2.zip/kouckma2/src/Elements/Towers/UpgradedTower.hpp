
#include"../Tower.hpp"

/**
 * game element UpgradedTower
 */
class UpgradedTower : public Tower {
public:
    /**
     * Constructor
     * 
     * @param [in] inX horizontal position of element
     * @param [in] inY vertical position of element
     */
    UpgradedTower(int inX, int inY);
    /**
     * Empty destructor
     */
    ~UpgradedTower();
    /**
     * Clones element.
     * 
     * @param [out] new Element
     */
    Element * clone();
    /**
     * Gets char representing this Element.
     * 
     * @param [out] char
     */
    char getChar();
    /**
     * Prints element to given window.
     * 
     * @param [in] win
     */
    void print(WINDOW * win);
    /**
     * Sets cooldown back according to default value.
     */
    void setCooldown();
};
