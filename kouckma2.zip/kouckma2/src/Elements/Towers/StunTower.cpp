

#include"StunTower.hpp"

StunTower::StunTower(int inX, int inY) : Tower(inX, inY) {
    reach = 1;
    damage = STUNDAMAGE;
    hasStun = 1;
}

StunTower::~StunTower() {
}

void StunTower::print(WINDOW * win) {
    waddch(win, 'S');
    refresh();
}

Element * StunTower::clone() {
    return new StunTower(*this);
}

void StunTower::setCooldown() {
    cooldown = STUNCOOLDOWN;
}

char StunTower::getChar() {
    return 'S';
}