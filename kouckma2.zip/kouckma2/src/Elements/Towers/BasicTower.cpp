

#include"BasicTower.hpp"

BasicTower::BasicTower(int inX, int inY) : Tower(inX, inY) {
    reach = 1;
    damage = BASICDAMAGE;
    hasStun = 0;
}

BasicTower::~BasicTower() {
}

void BasicTower::print(WINDOW * win) {
    waddch(win, 'B');
    refresh();
}

Element * BasicTower::clone() {
    return new BasicTower(*this);
}

void BasicTower::setCooldown() {
    cooldown = BASICCOOLDOWN;
}

char BasicTower::getChar() {
    return 'B';
}