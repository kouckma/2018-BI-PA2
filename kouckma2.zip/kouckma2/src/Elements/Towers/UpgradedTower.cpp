

#include"UpgradedTower.hpp"

UpgradedTower::UpgradedTower(int inX, int inY) : Tower(inX, inY) {
    reach = 2;
    damage = UPGRADEDDAMAGE;
    hasStun = 0;
}

UpgradedTower::~UpgradedTower() {
}

void UpgradedTower::print(WINDOW * win) {
    waddch(win, 'A');
    refresh();
}

Element * UpgradedTower::clone() {
    return new UpgradedTower(*this);
}

void UpgradedTower::setCooldown() {
    cooldown = UPGRADEDCOOLDOWN;
}

char UpgradedTower::getChar() {
    return 'A';
}