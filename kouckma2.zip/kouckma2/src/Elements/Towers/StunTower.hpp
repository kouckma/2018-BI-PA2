
#include"../Tower.hpp"

/**
 * game element StunTower
 */
class StunTower : public Tower {
public:
    /**
     * Constructor
     * 
     * @param [in] inX horizontal position of element
     * @param [in] inY vertical position of element
     */
    StunTower(int inX, int inY);
    /**
     * Empty destructor
     */
    ~StunTower();
    /**
     * Clones element.
     * 
     * @param [out] new Element
     */
    Element * clone();
    /**
     * Prints element to given window.
     * 
     * @param [in] win
     */
    void print(WINDOW * win);
    /**
     * Gets char representing this Element.
     * 
     * @param [out] char
     */
    char getChar();
    /**
     * Sets cooldown back according to default value.
     */
    void setCooldown();
};
