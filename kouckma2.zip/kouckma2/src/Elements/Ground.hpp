#ifndef GROUND_H
#define GROUND_H


#include"Element.hpp"

/**
 * game element Ground
 */
class Ground : public Element {
public:
    /**
     * Constructor
     * 
     * @param [in] inX horizontal position of element
     * @param [in] inY vertical position of element
     * @param [in] intype type of element
     */
    Ground(int inX, int inY, int intype = GROUND);
    /**
     * Empty destructor
     */
    ~Ground();
    /**
     * Clones element.
     * 
     * @param [out] new Element
     */
    Element * clone();
    /**
     * Prints element to given window.
     * 
     * @param [in] win
     */
    void print(WINDOW * win);
    /**
     * Acts out event of Element, which may change depending on given Element
     */
    void event();
    /**
     * Gets char representing this Element.
     * 
     * @param [out] char
     */
    char getChar();
};


#endif
