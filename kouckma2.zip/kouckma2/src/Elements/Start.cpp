

#include"Start.hpp"

void Start::event() {

}

Start::Start(int inX, int inY, int intype)
: Element(inX, inY, intype) {
}

Start::~Start() {
}

void Start::print(WINDOW * win) {
    waddch(win, '<');
    refresh();
}

Element * Start::clone() {
    return new Start(*this);
}

char Start::getChar() {
    return '<';
}