
#include"Element.hpp"

/**
 * game element Start
 */
class Start : public Element {
public:
    /**
     * Constructor
     * 
     * @param [in] inX horizontal position of element
     * @param [in] inY vertical position of element
     * @param [in] intype type of element
     */
    Start(int inX, int inY, int intype = START);
    /**
     * Empty destructor
     */
    ~Start();
    /**
     * Clones element.
     * 
     * @param [out] new Element
     */
    Element * clone();
    /**
     * Prints element to given window.
     * 
     * @param [in] win
     */
    void print(WINDOW * win);
    /**
     * Acts out event of Element, which may change depending on given Element
     */
    void event();
    /**
     * Gets char representing this Element.
     * 
     * @param [out] char
     */
    char getChar();
};
