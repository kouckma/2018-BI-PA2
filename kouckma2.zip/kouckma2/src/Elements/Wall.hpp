
#include"Element.hpp"

/**
 * game element Wall
 */
class Wall : public Element {
public:
    /**
     * Constructor
     * 
     * @param [in] inX horizontal position of element
     * @param [in] inY vertical position of element
     * @param [in] intype type of element
     */
    Wall(int inX, int inY, int intype = WALL);
    /**
     * Empty destructor
     */
    ~Wall();
    /**
     * Clones element.
     * 
     * @param [out] new Element
     */
    Element * clone();
    /**
     * Gets char representing this Element.
     * 
     * @param [out] char
     */
    char getChar();
    /**
     * Prints element to given window.
     * 
     * @param [in] win
     */
    void print(WINDOW * win);
    /**
     * Acts out event of Element, which may change depending on given Element
     */
    void event();
};
