#ifndef ENEMY_H
#define ENEMY_H


#include"Element.hpp"

/**
 * game element Enemy (parent class)
 */
class Enemy : public Element {
protected:
    /**
     * HP of enemy
     */
    int health = 0;
    /**
     * determines if enemy is currently stunned
     */
    int stunned = 0;
    /**
     * bounty of enemy
     */
    int bounty = 0;
public:
    /**
     * type of enemy
     */
    int enemytype = 0;
    /**
     * Constructor
     * 
     * @param [in] inX horizontal position of element
     * @param [in] inY vertical position of element
     * @param [in] inHealth HP of enemy
     * @param [in] intype type of element
     */
    Enemy(int inX, int inY, int inHealth = MOBHP, int intype = ENEMY);
    /**
     * Clones element.
     * 
     * @param [out] new Element
     */
    virtual Element * clone();
    /**
     * Gets char representing this Element.
     * 
     * @param [out] char
     */
    virtual char getChar();
    /**
     * Prints element to given window.
     * 
     * @param [in] win
     */
    virtual void print(WINDOW * win);
    /**
     * Acts out event of Element, which may change depending on given Element.
     */
    void event();
    /**
     * Removes HP from enemy, and stuns him if given stun.
     * 
     * @param [in] damage damage of tower
     * @param [in] inStun stun of tower
     */
    void getShot(int damage, int inStun);
    /**
     * Returns HP of enemy.
     * 
     * @param [out] health
     */
    int getHealth();
    /**
     * Returns bounty value of enemy.
     * 
     * @param [out] bounty
     */
    int getBounty();
    /**
     * Returns if enemy is stunned.
     * 
     * @param [out] stun
     */
    int isStunned();
    /**
     * Empty destructor
     */
    virtual ~Enemy();
};

#endif