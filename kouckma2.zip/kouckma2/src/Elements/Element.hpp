
#ifndef ELEMENT_H
#define ELEMENT_H


#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <ncurses.h>
#include <vector>
#include <memory>

#include "../Constants.hpp" 

using namespace std;

/**
 * parent class for all Elements in game
 */
class Element {
public:
    /**
     * Horizontal and vertical coordinates of Element
     */
    int x, y;
    /**
     * Type of Element
     */
    int type;
    /**
     * Constructor
     * 
     * @param [in] inX horizontal position of element
     * @param [in] inY vertical position of element
     * @param [in] intype type of element
     */
    Element(int inX, int inY, int intype);
    /**
     * Prints element to given window.
     * 
     * @param [in] win
     */
    virtual void print(WINDOW * win);
    /**
     * Acts out event of Element, which may change depending on given Element
     */
    virtual void event();
    /**
     * Sets new position of element
     * 
     * @param inx new x position
     * @param iny new y position
     */
    void setXY(int inx, int iny);
    /**
     * Clones element.
     * 
     * @param [out] new Element
     */
    virtual Element * clone();
    /**
     * Gets char representing this Element.
     * 
     * @param [out] char
     */
    virtual char getChar();
    /**
     * Empty destructor
     */
    virtual ~Element();
};


#endif
