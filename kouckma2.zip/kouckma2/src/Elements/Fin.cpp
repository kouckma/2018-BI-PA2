
#include"Fin.hpp"

void Fin::event() {
}

Fin::~Fin() {
}

Fin::Fin(int inX, int inY, int intype)
: Element(inX, inY, intype) {
}

void Fin::print(WINDOW * win) {
    waddch(win, '<');
    refresh();
}

Element * Fin::clone() {
    return new Fin(*this);
}

char Fin::getChar() {
    return '<';
}