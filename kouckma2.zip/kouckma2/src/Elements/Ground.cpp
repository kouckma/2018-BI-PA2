

#include"Ground.hpp"

void Ground::event() {

}

Ground::Ground(int inX, int inY, int intype)
: Element(inX, inY, intype) {
}

Ground::~Ground() {
}

void Ground::print(WINDOW * win) {
    waddch(win, ' ');
    refresh();
}

Element * Ground::clone() {
    return new Ground(*this);
}

char Ground::getChar() {
    return '.';
}