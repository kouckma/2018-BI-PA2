

#include"Tower.hpp"

char Tower::getChar() {
    return 'B';
}

void Tower::event() {
    if (cooldown > 0)cooldown--;
}

Tower::Tower(int inX, int inY, int intype)
: Element(inX, inY, intype) {
    cooldown = 0;
}

Tower::~Tower() {
}

void Tower::print(WINDOW * win) {
    waddch(win, 'A');
    refresh();
}

void Tower::setCooldown() {
    cooldown = 1;
}

Element * Tower::clone() {
    return new Tower(*this);
}

int Tower::canStun() {
    if (hasStun)return 1;
    else return 0;

}
