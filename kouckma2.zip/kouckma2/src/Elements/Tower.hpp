
#ifndef TOWER_H
#define TOWER_H



#include"Element.hpp"
#include"../Constants.hpp"

/**
 * game element Tower (parent class)
 */
class Tower : public Element {
public:
    int hasStun = 0;
    int reach = 1;
    int damage = BASICDAMAGE;
    int cooldown = 0;
    /**
     * Constructor
     * 
     * @param [in] inX horizontal position of element
     * @param [in] inY vertical position of element
     * @param [in] intype type of element
     */
    Tower(int inX, int inY, int intype = TOWER);
    /**
     * Empty destructor
     */
    ~Tower();
    /**
     * Clones element.
     * 
     * @param [out] new Element
     */
    virtual Element * clone();
    /**
     * Gets char representing this Element.
     * 
     * @param [out] char
     */
    virtual char getChar();
    /**
     * Prints element to given window.
     * 
     * @param [in] win
     */
    virtual void print(WINDOW * win);
    /**
     * Acts out event of Element, which may change depending on given Element
     */
    void event();
    /**
     * Sets cooldown back according to default value.
     */
    virtual void setCooldown();
    /**
     * Returns if this tower has the ability to stun.
     * 
     * @param [out] hasStun
     */
    int canStun();
};
#endif