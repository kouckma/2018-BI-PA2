#include"Mob.hpp"

Mob::Mob(int inX, int inY, int inHealth) : Enemy(inX, inY, inHealth) {
    enemytype = MOB;
    stunned = 0;
    bounty = MOBBOUNTY;
}

Mob::~Mob() {
}

void Mob::print(WINDOW* win) {
    waddch(win, '@');
    refresh();
}

Element * Mob::clone() {
    return new Mob(*this);
}

char Mob::getChar() {
    return '@';
}
