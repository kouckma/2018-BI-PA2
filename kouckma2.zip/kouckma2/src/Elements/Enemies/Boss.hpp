
#include"../Enemy.hpp"

/**
 * game element Boss
 */
class Boss : public Enemy {
public:
    /**
     * Constructor
     * 
     * @param [in] inX horizontal position of element
     * @param [in] inY vertical position of element
     * @param [in] inHealth HP of enemy
     */
    Boss(int inX, int inY, int inHealth = BOSSHP);
    /**
     * Empty destructor
     */
    ~Boss();
    /**
     * Prints element to given window.
     * 
     * @param [in] win
     */
    void print(WINDOW * win);
    /**
     * Clones element.
     * 
     * @param [out] new Element
     */
    Element * clone();
    /**
     * Gets char representing this Element.
     * 
     * @param [out] char
     */
    char getChar();
};

