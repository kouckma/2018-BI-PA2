#include"Boss.hpp"

Boss::Boss(int inX, int inY, int inHealth) : Enemy(inX, inY, inHealth) {
    enemytype = BOSS;
    stunned = 0;
    bounty = BOSSBOUNTY;
}

Boss::~Boss() {
}

void Boss::print(WINDOW* win) {
    waddch(win, '0');
    refresh();
}

Element * Boss::clone() {
    return new Boss(*this);
}

char Boss::getChar() {
    return '0';
}
