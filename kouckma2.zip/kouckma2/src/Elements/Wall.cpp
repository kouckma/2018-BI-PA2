
#include"Wall.hpp"

void Wall::event() {
}

Wall::Wall(int inX, int inY, int intype)
: Element(inX, inY, intype) {
}

Wall::~Wall() {
}

void Wall::print(WINDOW * win) {
    waddch(win, '#');
    refresh();
}

Element * Wall::clone() {
    return new Wall(*this);
}

char Wall::getChar() {
    return '#';
}
